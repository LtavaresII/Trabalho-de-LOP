var tamBloco = 40;
var x,y;
var dx,dy;
var w = 300;
var z = 300;
var t;
var u,r;
var q,e,o,p;
var tam,tam2;
var raio = 40;
var nivel = 1;
var pontos = 0;
var vidas = 3;

function preload(){
  imgParede = loadImage("image/tijolo.png");
}
cenario = [

  ['$','$','$','$','$','$','$','$','$','$','$'],
  ['$','&','%','%','%','%','%','%','%','&','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','%','$'],
  ['$','&','%','%','%','%','%','%','%','&','$'],
  ['$','$','$','$','$','$','$','$','$','$','$']
  
  ];

function quadrado(w,z){
	fill( 250, 0, 0);
  ellipse( w, z, raio, raio);
}
function PacMan(u,r){
	fill( 250, 250, 5);
  ellipse( u, r, raio, raio);
	
} 
function setup() {
  createCanvas(640, 640);
  background('#222222');
  frameRate(30);
  x = 300;
  y = 300;
  r = 100;
  u = 100;
  q = random( 40 , 360 );
  e = random( 40 , 360 );
  tam = 10;
  o = random( 40 , 360 );
  p = random( 40 , 360 );
  tam2 = 20;
  dx = Math.random(-10,10);
  dy = Math.random(-10,10); 
  t = 0;
}

function draw() {
  background('#222222');
  quadrado(x,y)
  
  x = x - dx;
  y = y - dy;
  
  t++;
  if( t > 30 ){
  dx = Math.random(-10,10);
  dy = Math.random(-10,10);
  t = 0;
  }
  if( x > 360 ){
	  x = 0;
  }
  if( y > 360 ){
	  y = 0;
  }
  if( x < 40 ){
	  x = 360;
  }
  if( y < 40 ){
	  y = 360;
  }
  
  
  PacMan(u,r)
  
   if (keyIsDown(LEFT_ARROW))
    u-=5;

  if (keyIsDown(RIGHT_ARROW))
    u+=5;

  if (keyIsDown(UP_ARROW))
    r-=5;

  if (keyIsDown(DOWN_ARROW))
    r+=5;
    
    fill(255);
    ellipse(q,e,tam,tam);
    fill(255);
    ellipse(o,p,tam2,tam2);
    
    if ( dist(x,y,u,r) < (raio + tamBloco)/2){
        vidas = vidas - 1;
}
    if ( dist(u,r,q,e) < (raio + tam)/2){
		pontos = pontos + 100;
	}
	if ( dist(u,r,o,p) < (raio + tam2)/2){
		pontos = pontos + 500;
	}
    
    fill(250,0,0);
    textSize(35)
    if(vidas > -1){
    text("Vidas: "+ vidas , 480, 120);
    }
    else{
    text("Vidas: "+ 0 , 480, 120);
	}
    fill(250, 0, 0 );
    textSize(35)
    if(pontos > -1 && pontos <= 999999){
    text("Pontos: \n" + pontos, 480, 180);
    }
    else{
	text("Pontos: \n" + 999999, 480, 180);	
	}
    fill(250, 0, 0 );
    textSize(35) 
    text("Nivel: " + nivel, 480, 280); 
    
    	image(imgParede,0,0);
  
  for(i = 0; i < cenario.length; i++){
    for(j = 0; j < cenario[0].length; j++){
      if(cenario[i][j] == '$'){
        image(imgParede,j*tamBloco,i*tamBloco);
  }
 }
}

}
