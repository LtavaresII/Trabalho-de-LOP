var tamBloco = 40;
var imgParede;

function preload(){
  imgParede = loadImage("tijolo.png");
}
cenario = [
  ['$','$','$','$','$','$','$','$','$','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','$','$','$','$','$','$','$','$','$'],
  
  ];
function colisao(px,py)

function setup() {
  createCanvas(600, 600);
  background('#222222');
  frameRate(30); 
}

function draw() {
  
  for(i = 0; i < cenario.length; i++){
    for(j = 0; j < cenario.length[0]; j++){
      if(cenario[i][j] === '$'){
        image(imgParede,j*tamBloco,i*tamBloco);
  }
 }
}
