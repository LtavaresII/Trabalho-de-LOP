var rw = 300;
var rz = 300;
var nivel = 1;
var pontos = 0;
var vidas = 3;
var px = 100;
var py = 100;
var tamBloco = 40;
var imgParede;

function preload(){
  imgParede = loadImage("tijolo.png");
}
cenario = [
  ['$','$','$','$','$','$','$','$','$','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','%','%','%','%','%','%','%','%','$'],
  ['$','$','$','$','$','$','$','$','$','$'],
  
  ];
function colisao(px,py)

function setup() {
  createCanvas(600, 600);
  background('#222222');
  frameRate(30); 
}

function draw() {
  
  for(i = 0; i < cenario.length; i++){
    for(j = 0; j < cenario.length[0]; j++){
      if(cenario[i][j] === '$'){
        image(imgParede,j*tamBloco,i*tamBloco);
  }
 }
} 
  if (keyIsDown(LEFT_ARROW)){
    x+=5;

  if (keyIsDown(RIGHT_ARROW))
    x+=5;

  if (keyIsDown(UP_ARROW))
    y-=5;

  if (keyIsDown(DOWN_ARROW))
    y+=5;
  
  clear();
  background('#222222');
    noStroke();
  fill( 250, 250, 5);
  ellipse( px, py, 40, 40);
  
   noStroke();
  fill( 250, 0, 0);
  rect( rw, rz, 40, 40);
  w = w - 2
  z = z - 2
  if(w < 0 || z < 0){
     w = 300
     z = 300
  }
  
    noStroke();
  fill(250,0,0);
  textSize(35)
text("Vidas: "+ vidas , 420, 120);
  fill(250, 0, 0 );
  textSize(35)
text("Pontos: " + pontos, 420, 180);
  fill(250, 0, 0 );
  textSize(35) 
text("Nivel: " + nivel, 420, 240);

}

